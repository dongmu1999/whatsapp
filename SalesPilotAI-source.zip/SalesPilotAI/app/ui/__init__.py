"""PySide6 用户界面。"""
